"""The one owner of the contract version; the wheel metadata reads it."""

__version__ = "4.4.0"
