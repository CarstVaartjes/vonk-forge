"""The one owner of the contract version; the wheel metadata reads it."""

__version__ = "5.7.0"
