"""Public hardware evidence and pure, identity-based qualification views.

No opaque messages or infrastructure identifiers cross this boundary. Summaries
and codes are closed vocabularies; references identify public fixes or evidence
bytes, never a host, request, operation or local artifact path.
"""

from enum import StrEnum
from typing import Annotated, Literal, Self

from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    StrictInt,
    model_validator,
)

from vonk_forge_contracts._schema_version import QualificationEvidenceSchemaVersion
from vonk_forge_contracts.recipe import Identifier
from vonk_forge_contracts.unrecognised import KeepUnrecognised, UnrecognisedWord

Digest = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
SourceSHA = Annotated[str, Field(pattern=r"^[0-9a-f]{40}$")]
# Public Forge tags, numbered prereleases and source builds. Arbitrary build
# labels can contain hostnames; they are not public platform version evidence.
Version = Annotated[
    str,
    Field(
        max_length=96,
        pattern=r"^v?[0-9]+\.[0-9]+\.[0-9]+(?:(?:~|-)(?:dev|alpha|beta|rc)[.-][0-9]+)?(?:\+g[0-9a-f]{7,40})?$",
    ),
]
RecipeKey = Annotated[str, Field(pattern=r"^[a-z0-9][a-z0-9-]*/[a-z0-9][a-z0-9-]*$")]


class PublicQualificationModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class QualificationStatus(StrEnum):
    WORKING = "Working"
    RECHECK = "Re-check: worked before"
    FIX_TO_VERIFY = "Fix to verify"
    FAILED_RECIPE = "Failed: recipe"
    BLOCKED_PLATFORM = "Blocked: platform"
    UNTESTED = "Untested"
    CANNOT_TEST = "Can't test here"
    TESTING = "Testing now"
    NOT_YET_VERIFIED = "Not yet verified"


class QualificationEvidenceStep(StrEnum):
    SMOKE = "smoke"


class QualificationOutcome(StrEnum):
    PASSED = "passed"
    FAILED = "failed"


class QualificationBlame(StrEnum):
    RECIPE = "recipe"
    PLATFORM = "platform"


class QualificationCauseCode(StrEnum):
    HARDWARE_PASS = "qualification.hardware_pass"
    RECIPE_FAILURE = "qualification.recipe_failure"
    PLATFORM_FAILURE = "qualification.platform_failure"
    RUNTIME_EXIT = "recipe.runtime_exit"
    RUNTIME_OOM = "recipe.runtime_oom"
    MODEL_INTEGRITY = "model.digest_mismatch"
    RECIPE_INTEGRITY = "recipe.digest_mismatch"
    INVALID_DEFINITION = "recipe.invalid_definition"
    INVALID_DOCUMENT = "recipe.invalid_document"
    INVALID_OPTION = "recipe.invalid_option"
    BUILD_POLICY = "dockerfile.heredoc_forbidden"
    SERVING_ASSERTION = "qualification.serving_assertion"
    JOB_FAILURE = "qualification.job_failure"


class QualificationSummary(StrEnum):
    PASSED = "Hardware checks passed"
    RECIPE_FAILED = "Recipe checks failed; needs fix"
    PLATFORM_FAILED = "Platform issue under fix"
    RUNTIME_EXIT = "Recipe runtime exited; needs fix"
    RUNTIME_OOM = "Recipe runtime exceeded available memory; needs fix"
    MODEL_INTEGRITY = "Model content integrity check failed; needs fix"
    INVALID_RECIPE = "Recipe definition or build policy check failed; needs fix"
    SERVING_ASSERTION = "Serving checks failed; needs fix"
    JOB_FAILURE = "Artifact job failed; needs fix"


class QualificationSourceFailureClass(StrEnum):
    SERVING_ASSERTION = "smoke-assertion"
    JOB_FAILED = "job-failed"
    RECIPE_DATA = "recipe-data"


QUALIFICATION_SUMMARIES = {
    QualificationCauseCode.HARDWARE_PASS: QualificationSummary.PASSED,
    QualificationCauseCode.RECIPE_FAILURE: QualificationSummary.RECIPE_FAILED,
    QualificationCauseCode.PLATFORM_FAILURE: QualificationSummary.PLATFORM_FAILED,
    QualificationCauseCode.RUNTIME_EXIT: QualificationSummary.RUNTIME_EXIT,
    QualificationCauseCode.RUNTIME_OOM: QualificationSummary.RUNTIME_OOM,
    QualificationCauseCode.MODEL_INTEGRITY: QualificationSummary.MODEL_INTEGRITY,
    QualificationCauseCode.RECIPE_INTEGRITY: QualificationSummary.MODEL_INTEGRITY,
    QualificationCauseCode.INVALID_DEFINITION: QualificationSummary.INVALID_RECIPE,
    QualificationCauseCode.INVALID_DOCUMENT: QualificationSummary.INVALID_RECIPE,
    QualificationCauseCode.INVALID_OPTION: QualificationSummary.INVALID_RECIPE,
    QualificationCauseCode.BUILD_POLICY: QualificationSummary.INVALID_RECIPE,
    QualificationCauseCode.SERVING_ASSERTION: QualificationSummary.SERVING_ASSERTION,
    QualificationCauseCode.JOB_FAILURE: QualificationSummary.JOB_FAILURE,
}


class QualificationQualityNote(StrEnum):
    ANSWER_VARIANCE = "Model output differed from the expected answer"
    CARRIED = "Carried from the identical document before the display split"
    CARRIED_MODEL_FACTS = (
        "Carried from the identical execution document before the Model facts split"
    )
    # A document whose execution bytes did not change, re-digested by a contract
    # move (only its Model pins differ): its evidence is the old digest's.
    CARRIED_IDENTICAL_EXECUTION = "Carried from the identical execution document"


class QualificationChange(StrEnum):
    RECIPE = "recipe"
    IMAGE = "image"
    SOURCE = "source"
    MODEL = "model"


class QualificationUnverifiedReason(StrEnum):
    NEVER_TESTED = "never tested"
    NEEDS_SPARKS = "needs more Sparks"
    PLATFORM_ISSUE = "platform issue under fix"
    INCOMPLETE_PROVENANCE = "historical platform or runtime identity unavailable"


class QualificationHardware(StrEnum):
    GB10 = "GB10"


class QualificationTopology(StrEnum):
    SINGLE = "single"
    MULTI = "multi"


class QualificationGlbProfile(StrEnum):
    """What a job recipe's ``glb-structure`` assertion requires of its GLB."""

    TRIANGLE_MESH = "triangle-mesh"
    TEXTURED = "textured"
    TEXTURED_PBR = "textured-pbr"
    SKINNED = "skinned"


class QualificationRuntimeImage(PublicQualificationModel):
    build_key: Digest
    image_digest: Annotated[str, Field(pattern=r"^sha256:[0-9a-f]{64}$")]


class QualificationIdentity(PublicQualificationModel):
    content_sha256: Digest
    source_bundle_sha256: Digest | None = None
    runtime_image: QualificationRuntimeImage | None = None
    model_digests: tuple[Digest, ...] = ()
    required_sparks: int | None = Field(default=None, ge=1)
    # Unknown historical model bindings must not equal a proven empty model set.
    models_resolved: bool = True

    @model_validator(mode="after")
    def canonical_models(self) -> Self:
        if self.model_digests != tuple(sorted(set(self.model_digests))):
            raise ValueError("model digests must be sorted and unique")
        return self

    @property
    def resolved(self) -> bool:
        return self.runtime_image is not None and self.models_resolved


class QualificationPlatform(PublicQualificationModel):
    controller_source_sha: SourceSHA | None = None
    controller_version: Version | None = None
    agent_version: Version | None = None
    # Words a newer minor may add; a consumer reader keeps them (``UnrecognisedWord``).
    hardware_class: Annotated[
        QualificationHardware | UnrecognisedWord, KeepUnrecognised
    ] = QualificationHardware.GB10
    spark_count: int | None = Field(default=None, ge=1)
    topology: Annotated[
        QualificationTopology | UnrecognisedWord | None, KeepUnrecognised
    ] = None

    @model_validator(mode="after")
    def check_topology(self) -> Self:
        if self.spark_count is None:
            if self.topology is not None:
                raise ValueError("topology requires a recorded Spark count")
            return self
        if isinstance(self.topology, UnrecognisedWord):
            return self
        expected = (
            QualificationTopology.SINGLE
            if self.spark_count == 1
            else QualificationTopology.MULTI
        )
        if self.topology is not None and self.topology != expected:
            raise ValueError("topology must match Spark count")
        return self

    @property
    def resolved(self) -> bool:
        return bool(
            (self.controller_source_sha or self.controller_version)
            and self.spark_count is not None
            and self.topology is not None
        )


class QualificationFixReference(PublicQualificationModel):
    # Always in the public Vonk repositories; no arbitrary URL or free text.
    issue_number: int | None = Field(default=None, gt=0)
    source_sha: SourceSHA | None = None

    @model_validator(mode="after")
    def nonempty(self) -> Self:
        if self.issue_number is None and self.source_sha is None:
            raise ValueError("a fix must identify an issue or source commit")
        return self


class QualificationEvidenceRecord(PublicQualificationModel):
    identity: QualificationIdentity
    # The published status is derived by the producer; a consumer only shows an
    # outcome or blame a newer minor added (``UnrecognisedWord``).
    outcome: Annotated[QualificationOutcome | UnrecognisedWord, KeepUnrecognised]
    blame: Annotated[QualificationBlame | UnrecognisedWord | None, KeepUnrecognised] = (
        None
    )
    # Words a newer minor may add; a consumer reader keeps them (``UnrecognisedWord``).
    cause_code: Annotated[QualificationCauseCode | UnrecognisedWord, KeepUnrecognised]
    cause_summary: Annotated[QualificationSummary | UnrecognisedWord, KeepUnrecognised]
    evidence_refs: tuple[Digest, ...] = ()
    tested_at: AwareDatetime
    platform: QualificationPlatform
    fix_reference: QualificationFixReference | None = None
    quality_notes: tuple[
        Annotated[QualificationQualityNote | UnrecognisedWord, KeepUnrecognised], ...
    ] = ()

    @model_validator(mode="after")
    def consistent_verdict(self) -> Self:
        if (
            self.outcome == QualificationOutcome.PASSED
            and self.platform.spark_count is not None
            and self.identity.required_sparks is not None
            and self.platform.spark_count != self.identity.required_sparks
        ):
            raise ValueError(
                "a hardware pass must use the recipe's required Spark count"
            )
        if (
            isinstance(self.outcome, UnrecognisedWord)
            or isinstance(self.blame, UnrecognisedWord)
            or isinstance(self.cause_code, UnrecognisedWord)
        ):
            # A verdict word a newer minor added: its rules are that minor's.
            return self
        if (self.outcome == QualificationOutcome.PASSED) != (self.blame is None):
            raise ValueError("passes have no blame; failures must identify blame")
        if (
            isinstance(self.cause_summary, QualificationSummary)
            and self.cause_summary != QUALIFICATION_SUMMARIES[self.cause_code]
        ):
            raise ValueError("summary must match the cause code")
        if (
            self.blame is None
            and self.cause_code != QualificationCauseCode.HARDWARE_PASS
        ):
            raise ValueError("a pass must identify successful hardware checks")
        if (
            self.blame == QualificationBlame.PLATFORM
            and self.cause_code != QualificationCauseCode.PLATFORM_FAILURE
        ):
            raise ValueError("platform failures cannot carry recipe blame")
        if self.blame == QualificationBlame.RECIPE and self.cause_code in (
            QualificationCauseCode.HARDWARE_PASS,
            QualificationCauseCode.PLATFORM_FAILURE,
        ):
            raise ValueError("recipe failures must identify a recipe cause")
        return self


class QualificationMeasuredRoleMemory(PublicQualificationModel):
    """What one role of one content held on hardware: a row keyed (content, role).

    ``steady_bytes`` is a serving recipe's role Spark host memory in use (total less
    available, the OS included) sampled after a smoke passed, the run alone on that Spark: an
    observation, never the recipe's declaration. ``budget_bytes`` is the vLLM
    utilization budget of the launch that ran (gpu-memory-utilization x Spark
    memory); ``None`` when it had none (an absolute KV pool, or another engine).
    """

    content_sha256: Digest
    role: Identifier
    steady_bytes: int = Field(ge=0)
    budget_bytes: int | None = Field(default=None, ge=0)

    @property
    def key(self) -> tuple[str, str]:
        return (self.content_sha256, self.role)


class RecipeQualificationEvidence(PublicQualificationModel):
    schema_version: QualificationEvidenceSchemaVersion = 1
    recipe_key: RecipeKey
    records: tuple[QualificationEvidenceRecord, ...] = ()
    # Its own table, keyed (content_sha256, role); empty means "not measured" and
    # is left out of the file, so evidence written before it keeps its bytes.
    measured_memory: tuple[QualificationMeasuredRoleMemory, ...] = Field(
        default=(), exclude_if=lambda rows: not rows
    )

    @model_validator(mode="after")
    def keyed_measurements(self) -> Self:
        keys = [row.key for row in self.measured_memory]
        if keys != sorted(set(keys)):
            raise ValueError("measured memory rows must be sorted and unique by key")
        return self


class QualificationDerivationInput(PublicQualificationModel):
    """Local report inputs, persisted without a derived status label."""

    evidence: RecipeQualificationEvidence
    current_identity: QualificationIdentity
    fleet_size: int = Field(ge=0)
    testing_now: bool


class QualificationStatusView(PublicQualificationModel):
    status: QualificationStatus
    changed: tuple[QualificationChange, ...] = ()
    last_pass: QualificationEvidenceRecord | None = None
    last_failure: QualificationEvidenceRecord | None = None
    reason: QualificationUnverifiedReason | None = None
    required_sparks: int = Field(ge=1)


class PublishedRoleMemory(PublicQualificationModel):
    """What one role of one content measured on hardware, as the catalog carries it.

    ``measured_peak_bytes`` is information: the role's workload bytes (the
    observed Spark use less the OS floor), never the recipe's declaration.
    ``peak_bytes`` is the one value admission reads: the measured peak, or, when
    that exceeds the admission maximum (``exceeds_admission_maximum``), the
    role's declared peak. The Controller admits on ``peak_bytes`` and, for the
    flagged case, shows a warning that hardware measured more than it can admit.
    """

    role: Identifier
    peak_bytes: int = Field(ge=0)
    measured_peak_bytes: int = Field(ge=0)
    exceeds_admission_maximum: bool = False

    @model_validator(mode="after")
    def _admits_the_measurement_unless_over_the_maximum(self) -> Self:
        if not self.exceeds_admission_maximum and (
            self.peak_bytes != self.measured_peak_bytes
        ):
            raise ValueError(
                "only an over-maximum measurement may differ from the peak"
            )
        return self


class PublishedMeasuredMemory(PublicQualificationModel):
    """A catalog entry's sibling key ``measured_memory``: roles of exactly its content.

    Never part of :class:`PublishedQualificationStatusView`, which forbids unknown
    fields: an older Controller reads the status unchanged and ignores this key.
    """

    roles: tuple[PublishedRoleMemory, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def _roles_are_sorted_and_unique(self) -> Self:
        names = [item.role for item in self.roles]
        if names != sorted(set(names)):
            raise ValueError("measured memory roles must be sorted and unique")
        return self


PublishedStatus = Literal[
    QualificationStatus.WORKING,
    QualificationStatus.RECHECK,
    QualificationStatus.FIX_TO_VERIFY,
    QualificationStatus.FAILED_RECIPE,
    QualificationStatus.NOT_YET_VERIFIED,
]


class PublishedQualificationStatusView(PublicQualificationModel):
    # A status, change or reason a newer minor adds: a consumer reader keeps the
    # word (``UnrecognisedWord``); the release's vocabulary carries its meaning.
    status: Annotated[PublishedStatus | UnrecognisedWord, KeepUnrecognised]
    changed: tuple[
        Annotated[QualificationChange | UnrecognisedWord, KeepUnrecognised], ...
    ] = ()
    last_pass: QualificationEvidenceRecord | None = None
    last_failure: QualificationEvidenceRecord | None = None
    reason: Annotated[
        QualificationUnverifiedReason | UnrecognisedWord | None, KeepUnrecognised
    ] = None
    required_sparks: StrictInt = Field(ge=1)


def _changes(
    previous: QualificationIdentity, current: QualificationIdentity
) -> tuple[QualificationChange, ...]:
    return tuple(
        change
        for change, differs in (
            (
                QualificationChange.RECIPE,
                previous.content_sha256 != current.content_sha256,
            ),
            (
                QualificationChange.IMAGE,
                previous.runtime_image is not None
                and previous.runtime_image != current.runtime_image,
            ),
            (
                QualificationChange.SOURCE,
                previous.source_bundle_sha256 is not None
                and previous.source_bundle_sha256 != current.source_bundle_sha256,
            ),
            (
                QualificationChange.MODEL,
                (previous.model_digests, previous.models_resolved)
                != (current.model_digests, current.models_resolved),
            ),
        )
        if differs
    )


def _same_content_identity(
    previous: QualificationIdentity, current: QualificationIdentity
) -> bool:
    # Compare recorded content, never turn missing historical provenance into a
    # changed pin. Publication separately requires fully resolved exact proof.
    return (
        previous.content_sha256 == current.content_sha256
        and (
            previous.source_bundle_sha256 is None
            or previous.source_bundle_sha256 == current.source_bundle_sha256
        )
        and previous.model_digests == current.model_digests
        and previous.models_resolved == current.models_resolved
        and previous.required_sparks in (None, current.required_sparks)
        and (
            previous.runtime_image is None
            or previous.runtime_image == current.runtime_image
        )
    )


def derive_status(
    evidence: RecipeQualificationEvidence,
    current_identity: QualificationIdentity,
    fleet_size: int,
    *,
    testing_now: bool,
) -> QualificationStatusView:
    """Latest hardware verdict on an identity wins; platform faults never erase proof.

    Exact historical proof restores on a revert, regardless of later results on
    other identities. Simultaneous contradictory results conservatively prefer
    the recipe failure. Input order never determines the outcome.
    """
    required_sparks = current_identity.required_sparks
    if required_sparks is None:
        raise ValueError("current identity requires the recipe's Spark count")
    records = sorted(
        evidence.records,
        key=lambda r: (
            r.tested_at,
            # On a tie in time the record of the current document is the later
            # one: a run recorded under two digests of the same execution never
            # lets the older digest decide.
            r.identity.content_sha256 == current_identity.content_sha256,
            r.outcome == QualificationOutcome.FAILED,
            r.model_dump_json(),
        ),
    )
    passes = [r for r in records if r.outcome == QualificationOutcome.PASSED]
    failures = [r for r in records if r.outcome == QualificationOutcome.FAILED]
    behavioural = [r for r in records if r.blame != QualificationBlame.PLATFORM]
    # Once this content has image-bound evidence, an older unbound pass cannot
    # certify a different image. Unbound failures still invalidate local proof.
    image_bound = any(
        r.identity.runtime_image is not None
        and _same_content_identity(
            r.identity.model_copy(update={"runtime_image": None}), current_identity
        )
        for r in behavioural
    )
    exact = [
        r
        for r in behavioural
        if _same_content_identity(r.identity, current_identity)
        and not (
            image_bound
            and r.identity.runtime_image is None
            and r.outcome == QualificationOutcome.PASSED
        )
    ]
    last_pass = passes[-1] if passes else None
    last_failure = failures[-1] if failures else None
    changed: tuple[QualificationChange, ...] = ()
    reason = None
    if exact:
        status = (
            QualificationStatus.WORKING
            if exact[-1].outcome == QualificationOutcome.PASSED
            else QualificationStatus.FAILED_RECIPE
        )
        if status == QualificationStatus.WORKING:
            last_pass = exact[-1]
        else:
            last_failure = exact[-1]
    elif any(_same_content_identity(r.identity, current_identity) for r in failures):
        status = QualificationStatus.BLOCKED_PLATFORM
        reason = QualificationUnverifiedReason.PLATFORM_ISSUE
        last_failure = [
            r for r in failures if _same_content_identity(r.identity, current_identity)
        ][-1]
        if last_pass:
            changed = _changes(last_pass.identity, current_identity)
    elif behavioural:
        previous = behavioural[-1]
        changed = _changes(previous.identity, current_identity)
        if previous.outcome == QualificationOutcome.FAILED:
            last_failure = previous
        status = (
            QualificationStatus.RECHECK
            if previous.outcome == QualificationOutcome.PASSED
            else QualificationStatus.FIX_TO_VERIFY
        )
    elif failures:
        status = QualificationStatus.BLOCKED_PLATFORM
        reason = QualificationUnverifiedReason.PLATFORM_ISSUE
    else:
        status = QualificationStatus.UNTESTED
        reason = QualificationUnverifiedReason.NEVER_TESTED
    if fleet_size < required_sparks and not exact:
        status = QualificationStatus.CANNOT_TEST
        reason = QualificationUnverifiedReason.NEEDS_SPARKS
    if testing_now:
        status = QualificationStatus.TESTING
    return QualificationStatusView(
        status=status,
        changed=changed,
        last_pass=last_pass,
        last_failure=last_failure,
        reason=reason,
        required_sparks=required_sparks,
    )


def published_status(
    evidence: RecipeQualificationEvidence, current_identity: QualificationIdentity
) -> PublishedQualificationStatusView:
    """Release-relative view: no lane state or publisher fleet leaks into the catalog."""
    required_sparks = current_identity.required_sparks
    if required_sparks is None:
        raise ValueError("current identity requires the recipe's Spark count")
    view = derive_status(evidence, current_identity, required_sparks, testing_now=False)
    certified: list[QualificationEvidenceRecord] = []
    if view.status == QualificationStatus.WORKING:
        # A later successful test with incomplete telemetry does not erase a
        # complete proof. A recipe failure on this identity invalidates older
        # proofs; a partial pass after that failure cannot revive them publicly.
        failures = [
            r.tested_at
            for r in evidence.records
            if _same_content_identity(r.identity, current_identity)
            and r.blame == QualificationBlame.RECIPE
        ]
        failed_at = max(failures) if failures else None
        certified = [
            r
            for r in evidence.records
            if r.identity == current_identity
            and r.outcome == QualificationOutcome.PASSED
            and r.identity.resolved
            and r.platform.resolved
            and (failed_at is None or r.tested_at > failed_at)
        ]
        if certified:
            view = view.model_copy(
                update={
                    "last_pass": max(
                        certified, key=lambda r: (r.tested_at, r.model_dump_json())
                    )
                }
            )
    reason = view.reason
    if view.status == QualificationStatus.UNTESTED and required_sparks > 1:
        # Describe the required topology without publishing our enrollment.
        reason = QualificationUnverifiedReason.NEEDS_SPARKS
    if view.status in (
        QualificationStatus.WORKING,
        QualificationStatus.FAILED_RECIPE,
    ) and (
        not current_identity.resolved
        or (view.status == QualificationStatus.WORKING and not certified)
        or (
            view.status == QualificationStatus.FAILED_RECIPE
            and view.last_failure is not None
            and not view.last_failure.platform.resolved
        )
    ):
        reason = QualificationUnverifiedReason.INCOMPLETE_PROVENANCE
    if view.status == QualificationStatus.BLOCKED_PLATFORM and view.last_pass:
        # A platform fault on the current identity after a pass elsewhere: the
        # recipe worked before and is re-tested, never "Not yet verified".
        view = view.model_copy(
            update={"status": QualificationStatus.RECHECK, "reason": None}
        )
        reason = None
    if (
        view.status
        in (
            QualificationStatus.UNTESTED,
            QualificationStatus.BLOCKED_PLATFORM,
            QualificationStatus.CANNOT_TEST,
            QualificationStatus.TESTING,
        )
        or reason == QualificationUnverifiedReason.INCOMPLETE_PROVENANCE
    ):
        view = view.model_copy(
            update={"status": QualificationStatus.NOT_YET_VERIFIED, "reason": reason}
        )
    return PublishedQualificationStatusView.model_validate(
        view.model_copy(update={"reason": reason}).model_dump()
    )


def qualification_evidence_json_schema() -> dict[str, object]:
    return RecipeQualificationEvidence.model_json_schema()


def qualification_status_json_schema() -> dict[str, object]:
    return QualificationStatusView.model_json_schema()


def published_qualification_status_json_schema() -> dict[str, object]:
    return PublishedQualificationStatusView.model_json_schema()


def published_measured_memory_json_schema() -> dict[str, object]:
    return PublishedMeasuredMemory.model_json_schema()
